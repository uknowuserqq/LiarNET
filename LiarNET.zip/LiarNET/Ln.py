#!/usr/bin/env python3

import os, sys, time, subprocess, re, socket, json, ipaddress, threading
import xml.etree.ElementTree as ET
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

VERSION    = "3.0"
IS_WINDOWS = os.name == "nt"
NO_WIN     = subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0

COLORS = {
    "red":    "\033[38;2;255;60;60m",
    "orange": "\033[38;2;255;140;0m",
    "yellow": "\033[38;2;255;220;0m",
    "green":  "\033[38;2;50;255;120m",
    "cyan":   "\033[38;2;0;220;255m",
    "white":  "\033[38;2;230;230;230m",
    "dim":    "\033[38;2;120;120;120m",
    "bold":   "\033[1m",
    "reset":  "\033[0m",
}

# Banner central de LiarNet con el nuevo estilo ASCII
MENU_BANNER = [
    " █████        ███                       ██████  █████           █████   ",
    "▒▒███        ▒▒▒                       ▒▒██████ ▒▒███           ▒▒███   ",
    " ▒███        ████   ██████   ████████   ▒███▒███ ▒███   ██████  ███████  ",
    " ▒███       ▒▒███  ▒▒▒▒▒███ ▒▒███▒▒███  ▒███▒▒███▒███  ███▒▒███▒▒▒███▒   ",
    " ▒███        ▒███   ███████  ▒███ ▒▒▒   ▒███ ▒▒██████ ▒███████   ▒███    ",
    " ▒███      █ ▒███  ███▒▒███  ▒███       ▒███  ▒▒█████ ▒███▒▒▒    ▒███ ███",
    " ███████████ █████▒▒████████ █████      █████ ▒ ▒█████▒▒██████  ▒▒█████ ",
    "▒▒▒▒▒▒▒▒▒▒▒ ▒▒▒▒▒  ▒▒▒▒▒▒▒▒ ▒▒▒▒▒       ▒▒▒▒▒    ▒▒▒▒▒  ▒▒▒▒▒▒     ▒▒▒▒▒  "
]
MENU_ITEMS = [
    ("1", "Scan available Wi-Fi networks"),
    ("2", "Inspect a specific Wi-Fi network"),
    ("3", "Scan devices on local network  [ARP + nmap]"),
    ("4", "Deep scan a single device"),
    ("5", "Port scan with custom range"),
    ("6", "Local Wi-Fi adapter info"),
    ("7", "Export last scan to JSON"),
    ("8", "Exit"),
]

_last_scan: dict = {}
_spinner_active = False

def c(key: str, text: str) -> str:
    return f"{COLORS.get(key,'')}{text}{COLORS['reset']}"

def bear_gradient(i: int, total: int) -> str:
    f = i / (total - 1) if total > 1 else 0
    return f"\033[38;2;255;{int(255*f)};{int(255*f)}m"

def banner():
    os.system("cls" if IS_WINDOWS else "clear")
    total = len(MENU_BANNER)
    for i, line in enumerate(MENU_BANNER):
        print(f"{bear_gradient(i, total)}{line}{COLORS['reset']}")
    ts   = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
    host = socket.gethostname()
    print(f"\n  {c('dim','v'+VERSION)}  {c('dim','|')}  {c('dim',ts)}  {c('dim','|')}  {c('dim',host)}\n")

def show_menu():
    banner()
    shades = ["255;40;40","255;80;80","255;115;115","255;150;150",
              "255;185;185","255;215;215","200;200;200","140;140;140"]
    for i,(num,label) in enumerate(MENU_ITEMS):
        print(f"  \033[38;2;{shades[i]}m( {num} ){COLORS['reset']}  {label}")
    print()

def section(title: str):
    w = 62
    print(f"\n{c('cyan','═'*w)}\n{c('cyan','  '+title)}\n{c('cyan','═'*w)}\n")

def ok(m):   print(c("green",  f"[+] {m}"))
def warn(m): print(c("yellow", f"[!] {m}"))
def err(m):  print(c("red",    f"[-] {m}"))
def info(m): print(c("cyan",   f"[*] {m}"))
def pause(): input(f"\n{c('dim','Presiona [Enter] para continuar...')}")

def spinner(label="Escaneando"):
    frames = ["⠋","⠙","⠹","⠸","⠼","⠴","⠦","⠧","⠇","⠏"]
    i = 0
    while _spinner_active:
        print(f"\r  {c('cyan', frames[i % len(frames)])}  {label}...", end="", flush=True)
        time.sleep(0.08)
        i += 1
    print("\r" + " " * 50 + "\r", end="", flush=True)

def run_spinner(label="Escaneando"):
    global _spinner_active
    _spinner_active = True
    t = threading.Thread(target=spinner, args=(label,), daemon=True)
    t.start()
    return t

def stop_spinner(t):
    global _spinner_active
    _spinner_active = False
    t.join()

def validate_ip(ip):
    try: ipaddress.ip_address(ip); return True
    except: return False

def validate_cidr(cidr):
    try: ipaddress.ip_network(cidr, strict=False); return True
    except: return False

def check_nmap():
    try:
        subprocess.check_output(["nmap","--version"], stderr=subprocess.DEVNULL,
                                 creationflags=NO_WIN)
        return True
    except FileNotFoundError:
        err("Nmap no encontrado. Descargalo en: https://nmap.org/download.html")
        return False


def get_local_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except:
        return "127.0.0.1"
    finally:
        s.close()

def get_gateway() -> str:
    try:
        out = subprocess.check_output(
            ["route", "print", "0.0.0.0"],
            text=True, encoding="cp850", errors="replace",
            creationflags=NO_WIN
        )
        m = re.search(r"0\.0\.0\.0\s+0\.0\.0\.0\s+(\d+\.\d+\.\d+\.\d+)", out)
        if m:
            return m.group(1)
    except:
        pass
    return "N/A"

def ip_to_cidr(ip: str) -> str:
    return ".".join(ip.split(".")[:3]) + ".0/24"


def get_arp_table() -> dict[str, str]:
    macs: dict[str, str] = {}
    try:
        out = subprocess.check_output(
            ["arp", "-a"],
            text=True, encoding="cp850", errors="replace",
            creationflags=NO_WIN
        )
        for line in out.splitlines():
            m = re.search(
                r"(\d{1,3}(?:\.\d{1,3}){3})\s+([0-9a-fA-F]{2}[-:][0-9a-fA-F]{2}"
                r"[-:][0-9a-fA-F]{2}[-:][0-9a-fA-F]{2}[-:][0-9a-fA-F]{2}[-:][0-9a-fA-F]{2})",
                line
            )
            if m:
                ip  = m.group(1)
                mac = m.group(2).upper().replace("-", ":")

                if not ip.endswith(".255") and not mac.startswith("FF:FF"):
                    macs[ip] = mac
    except Exception as e:
        warn(f"ARP table error: {e}")
    return macs

def populate_arp(cidr: str):
    try:
        net = ipaddress.ip_network(cidr, strict=False)
    except:
        return

    info(f"Poblando tabla ARP con ping flood al rango {cidr} (paralelo)...")

    def ping_host(ip):
        subprocess.call(
            ["ping", "-n", "1", "-w", "300", str(ip)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=NO_WIN
        )

    hosts = list(net.hosts())
    t = run_spinner(f"Ping a {len(hosts)} hosts")
    with ThreadPoolExecutor(max_workers=100) as ex:
        ex.map(ping_host, hosts)
    stop_spinner(t)
    time.sleep(0.5)  


def resolve_hostname(ip: str) -> str:
    try:
        return socket.gethostbyaddr(ip)[0]
    except:
        return "Desconocido"


OUI_TABLE: dict[str, str] = {
    "00:50:56": "VMware",            "00:0C:29": "VMware",
    "00:1A:11": "Google",            "AC:DE:48": "Private",
    "B8:27:EB": "Raspberry Pi",      "DC:A6:32": "Raspberry Pi",
    "E4:5F:01": "Raspberry Pi",      "00:1B:44": "SanDisk",
    "3C:5A:B4": "Google Chromecast", "F4:F5:D8": "Google",
    "18:B4:30": "Nest Labs",         "44:65:0D": "Amazon",
    "68:37:E9": "Amazon",            "F0:27:2D": "Amazon",
    "74:C2:46": "Amazon",            "FC:65:DE": "Amazon",
    "B4:7C:9C": "Apple",             "A4:C3:F0": "Apple",
    "78:4F:43": "Apple",             "00:17:F2": "Apple",
    "00:1E:52": "Apple",             "3C:07:54": "Apple",
    "58:55:CA": "Apple",             "00:03:93": "Apple",
    "34:36:3B": "Apple",             "00:26:BB": "Apple",
    "8C:85:90": "Apple",             "D0:03:4B": "Apple",
    "00:1C:B3": "Apple",             "F0:D1:A9": "Apple",
    "60:03:08": "Apple",             "00:23:32": "Apple",
    "E0:F8:47": "Samsung",           "B8:BC:1B": "Samsung",
    "40:4E:36": "Samsung",           "C8:38:70": "Samsung",
    "00:16:6C": "Samsung",           "78:1F:DB": "Samsung",
    "48:44:F7": "Samsung",           "BC:14:EF": "Samsung",
    "10:1D:C0": "Samsung",           "A4:07:B6": "Samsung",
    "00:0F:B5": "Netgear",           "20:4E:7F": "Netgear",
    "A0:21:B7": "Netgear",           "00:14:6C": "Netgear",
    "1C:1D:86": "Netgear",           "84:1B:5E": "Netgear",
    "C0:3F:0E": "Netgear",           "00:09:5B": "Netgear",
    "30:46:9A": "TP-Link",           "50:C7:BF": "TP-Link",
    "EC:08:6B": "TP-Link",           "B0:95:75": "TP-Link",
    "AC:84:C6": "TP-Link",           "00:27:19": "TP-Link",
    "E8:DE:27": "TP-Link",           "C4:6E:1F": "TP-Link",
    "DC:FE:18": "TP-Link",           "18:A6:F7": "TP-Link",
    "F4:EC:38": "TP-Link",           "98:DA:C4": "TP-Link",
    "50:D4:F7": "TP-Link",           "00:1D:0F": "TP-Link",
    "00:25:86": "TP-Link",           "54:A7:03": "TP-Link",
    "00:1F:1F": "D-Link",            "00:26:5A": "D-Link",
    "1C:7E:E5": "D-Link",            "78:54:2E": "D-Link",
    "28:10:7B": "D-Link",            "90:94:E4": "D-Link",
    "00:0D:88": "D-Link",            "00:17:9A": "D-Link",
    "00:1B:11": "D-Link",            "B8:A3:86": "D-Link",
    "F0:7D:68": "Cisco",             "00:17:0F": "Cisco",
    "00:1A:A1": "Cisco",             "58:8D:09": "Cisco",
    "00:0B:BE": "Cisco",             "00:1C:57": "Cisco",
    "00:22:55": "Cisco",             "00:1E:F7": "Cisco",
    "3C:8C:F8": "Huawei",            "00:E0:FC": "Huawei",
    "28:6E:D4": "Huawei",            "04:02:1F": "Huawei",
    "00:9A:CD": "Huawei",            "B4:15:13": "Huawei",
    "B8:08:D7": "Huawei",            "E8:CD:2D": "Huawei",
    "48:00:31": "Huawei",            "6C:8D:C1": "Huawei",
    "00:90:4C": "Asus",              "00:E0:18": "Asus",
    "04:92:26": "Asus",              "08:60:6E": "Asus",
    "10:BF:48": "Asus",              "14:DA:E9": "Asus",
    "BC:EE:7B": "Asus",              "2C:56:DC": "Asus",
    "50:46:5D": "Asus",              "1C:87:2C": "Asus",
    "00:26:18": "Asus",              "F8:32:E4": "Asus",
    "00:1B:21": "Intel",             "00:21:6A": "Intel",
    "00:23:14": "Intel",             "8C:EC:4B": "Intel",
    "A4:34:D9": "Intel",             "B4:B6:76": "Intel",
    "AC:7B:A1": "Intel",             "60:57:18": "Intel",
    "8C:8D:28": "Intel",             "48:45:20": "Intel",
    "FC:AA:14": "Intel",             "00:1F:3C": "Intel",
    "00:24:D7": "Intel",             "5C:51:4F": "Intel",
    "54:27:1E": "Intel",             "10:02:B5": "Intel",
    "00:22:FA": "Intel",             "7C:7A:91": "Intel",
    "8C:0D:76": "Intel",             "68:05:CA": "Intel",
    "E4:70:B8": "Intel",             "F8:16:54": "Intel",
    "8C:EC:4B": "Intel",             "00:1F:3B": "Intel",
    "00:21:5D": "Intel",             "00:18:DE": "Intel",
    "90:2B:34": "Intel",             "68:EC:C5": "Intel",
    "18:66:DA": "Intel",             "AC:37:43": "Intel",
    "A4:02:B9": "Intel",             "10:F0:05": "Intel",
    "F4:06:69": "Intel",             "BC:0F:9A": "Intel",
    "00:1C:C0": "Intel",             "00:24:D6": "Intel",
    "B0:C0:90": "Intel",             "10:BE:F5": "Intel",
    "08:9E:08": "Intel",             "0C:8B:FD": "Intel",
}

def oui_lookup(mac: str) -> str:
    if not mac or mac == "N/A":
        return "Desconocido"
    prefix = mac[:8].upper()
    return OUI_TABLE.get(prefix, "Desconocido")


def run_nmap(target: str, extra_args: list, timeout: int = 150) -> str | None:
    if not check_nmap():
        return None
    cmd = ["nmap"] + extra_args + [target, "-oX", "-"]
    info(f"nmap {' '.join(extra_args)} {target}")
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, creationflags=NO_WIN)
        if r.returncode not in (0, 1):
            err(f"nmap retornó código {r.returncode}")
            if r.stderr: print(c("dim", r.stderr[:300]))
            return None
        return r.stdout
    except subprocess.TimeoutExpired:
        err(f"Timeout ({timeout}s). Reducí el rango o los puertos.")
        return None
    except Exception as e:
        err(f"Error lanzando nmap: {e}")
        return None

def parse_nmap_xml(xml_str: str) -> list[dict]:
    hosts = []
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError as e:
        err(f"XML inválido: {e}")
        return hosts

    for host in root.findall("host"):
        if host.find("status").get("state") != "up":
            continue
        entry = {"ip":"?","mac":"N/A","vendor":"N/A","hostname":"Desconocido",
                 "os":[],"ports":[]}
        for addr in host.findall("address"):
            if addr.get("addrtype") == "ipv4":
                entry["ip"] = addr.get("addr","?")
            elif addr.get("addrtype") == "mac":
                entry["mac"]    = addr.get("addr","N/A").upper()
                entry["vendor"] = addr.get("vendor") or "N/A"
        hn_node = host.find("hostnames")
        if hn_node is not None:
            hn = hn_node.find("hostname")
            if hn is not None:
                entry["hostname"] = hn.get("name","Desconocido")
        os_node = host.find("os")
        if os_node is not None:
            for om in os_node.findall("osmatch"):
                entry["os"].append({"name":om.get("name"),"accuracy":om.get("accuracy")})
        ports_node = host.find("ports")
        if ports_node is not None:
            for port in ports_node.findall("port"):
                st = port.find("state")
                if st is None or st.get("state") != "open":
                    continue
                svc = port.find("service")
                entry["ports"].append({
                    "port":    port.get("portid"),
                    "proto":   port.get("protocol"),
                    "service": svc.get("name","?")    if svc is not None else "?",
                    "product": svc.get("product","")  if svc is not None else "",
                    "version": svc.get("version","")  if svc is not None else "",
                })
        hosts.append(entry)
    return hosts

def print_hosts(hosts: list[dict], arp_table: dict = {}):
    if not hosts:
        warn("No se encontraron hosts activos.")
        return
    for h in hosts:
        if h["mac"] == "N/A" and h["ip"] in arp_table:
            h["mac"] = arp_table[h["ip"]]
        if h["vendor"] == "N/A" and h["mac"] != "N/A":
            h["vendor"] = oui_lookup(h["mac"])
        if h["hostname"] == "Desconocido":
            h["hostname"] = resolve_hostname(h["ip"])

        ok(f"Host activo: {c('bold', h['ip'])}")
        print(f"    ├── Hostname:    {h['hostname']}")
        mac_str = h['mac'] if h['mac'] != "N/A" else c("dim","No disponible (requiere admin)")
        print(f"    ├── MAC:         {mac_str}")
        print(f"    └── Fabricante:  {h['vendor']}")
        if h["os"]:
            best = h["os"][0]
            print(f"    └── OS:          {best['name']}  ({best['accuracy']}%)")
        if h["ports"]:
            print(f"    └── {c('yellow','Puertos abiertos')}:")
            for p in h["ports"]:
                full = p["service"]
                if p["product"]: full += f" — {p['product']}"
                if p["version"]: full += f" {p['version']}"
                print(f"         └── {c('green',p['port'])}/{p['proto']}  →  {full}")
        print(f"    {'─'*52}")


def op1_scan_available_wifi():
    section("Redes Wi-Fi disponibles")
    try:
        raw = subprocess.check_output(
            ["netsh", "wlan", "show", "networks", "mode=bssid"],
            text=True, encoding="cp850", errors="replace",
            creationflags=NO_WIN
        )
    except Exception as e:
        err(f"netsh falló: {e}")
        pause(); return

    blocks = re.split(r"(?m)^SSID\s+\d+\s*:", raw)
    redes = []
    for block in blocks[1:]:
        lines = block.strip().splitlines()
        ssid = lines[0].strip() if lines else "(oculto)"

        tipo  = next((l.split(":",1)[1].strip() for l in lines
                      if re.search(r"[Tt]ipo de red|[Nn]etwork type", l)), "?")
        auth  = next((l.split(":",1)[1].strip() for l in lines
                      if re.search(r"[Aa]utenticaci|[Aa]uthentication", l)), "?")
        cipher= next((l.split(":",1)[1].strip() for l in lines
                      if re.search(r"[Cc]ifrado|[Cc]ipher", l)), "?")

        bssids = re.findall(r"BSSID\s+\d+\s*:\s*([0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5})", block)
        chans  = re.findall(r"(?:[Cc]anal|[Cc]hannel)\s*:\s*(\d+)", block)
        sigs   = re.findall(r"(?:[Ss]e.al|[Ss]ignal)\s*:\s*(\d+)\s*%", block)

        redes.append({
            "ssid": ssid, "auth": auth, "cipher": cipher,
            "tipo": tipo,
            "bssids": list(zip(bssids,
                               chans  + ["?"]*(len(bssids)-len(chans)),
                               sigs   + ["?"]*(len(bssids)-len(sigs))))
        })

    if not redes:
        warn("No se encontraron redes. ¿Está el Wi-Fi activado?")
        pause(); return

    print(f"  {c('dim', f'Total detectadas: {len(redes)}')}\n")
    for i, red in enumerate(redes, 1):
        sig_vals = [int(s) for b,ch,s in red["bssids"] if s.isdigit()]
        best_sig = max(sig_vals) if sig_vals else 0
        sig_color = "green" if best_sig >= 70 else ("yellow" if best_sig >= 40 else "dim")
        sig_bar   = ("█" * (best_sig // 10)).ljust(10)

        print(f"  {c('cyan', f'[{i:02d}]')}  {c('bold', red['ssid'])}")
        print(f"       Auth: {c('yellow', red['auth'])}   Cifrado: {red['cipher']}")
        if best_sig:
            print(f"       Señal: {c(sig_color, sig_bar)} {best_sig}%")
        for bssid, ch, sig in red["bssids"]:
            vendor = oui_lookup(bssid.upper().replace("-",":"))
            print(f"       {c('dim','├──')} BSSID: {bssid.upper()}  Canal: {ch}  Señal: {sig}%  [{vendor}]")
        print()
    pause()


def op2_inspect_wifi():
    section("Inspección detallada de red Wi-Fi")
    target = input(c("yellow","  SSID objetivo → ")).strip()
    if not target:
        warn("No ingresaste ningún SSID."); pause(); return
    try:
        raw = subprocess.check_output(
            ["netsh","wlan","show","networks","mode=bssid"],
            text=True, encoding="cp850", errors="replace",
            creationflags=NO_WIN
        )
    except Exception as e:
        err(f"netsh error: {e}"); pause(); return

    blocks = re.split(r"(?m)^SSID\s+\d+\s*:", raw)
    found  = False
    for block in blocks[1:]:
        lines = block.strip().splitlines()
        ssid  = lines[0].strip()
        if ssid.lower() != target.lower():
            continue
        found = True
        ok(f"Red: {c('bold', ssid)}")

        auth   = next((l.split(":",1)[1].strip() for l in lines
                       if re.search(r"[Aa]utenticaci|[Aa]uthentication", l)), "?")
        cipher = next((l.split(":",1)[1].strip() for l in lines
                       if re.search(r"[Cc]ifrado|[Cc]ipher", l)), "?")
        print(f"  Auth: {auth}  |  Cifrado: {cipher}\n")

        bssids = re.findall(r"BSSID\s+\d+\s*:\s*([0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5})", block)
        chans  = re.findall(r"(?:[Cc]anal|[Cc]hannel)\s*:\s*(\d+)", block)
        sigs   = re.findall(r"(?:[Ss]e.al|[Ss]ignal)\s*:\s*(\d+)\s*%", block)
        rates  = re.findall(r"(?:[Vv]elocidades b.sicas|[Bb]asic rates)\s*.*?:\s*(.*)", block)
        other  = re.findall(r"(?:[Oo]tras velocidades|[Oo]ther rates)\s*.*?:\s*(.*)", block)

        for i, bssid in enumerate(bssids):
            mac = bssid.upper().replace("-",":")
            ch  = chans[i]  if i < len(chans) else "?"
            sig = sigs[i]   if i < len(sigs)  else "?"
            vendor = oui_lookup(mac)
            sig_int = int(sig) if sig.isdigit() else 0
            bar = ("█" * (sig_int // 10)).ljust(10)
            sig_color = "green" if sig_int >= 70 else ("yellow" if sig_int >= 40 else "dim")

            print(f"  {c('green','AP #'+str(i+1))}")
            print(f"    ├── BSSID:      {mac}")
            print(f"    ├── Fabricante: {vendor}")
            print(f"    ├── Canal:      {ch}")
            sig_display = f"{c(sig_color, bar)} {sig}%"
            print(f"    └── Señal:      {sig_display}")
            if rates and i < len(rates):
                print(f"    └── Tasas base: {rates[i].strip()}")
            print()

    if not found:
        warn(f"No se encontró la red '{target}' en rango.")
    pause()

def op3_scan_local_network():
    section("Escaneo de dispositivos en red local")
    local_ip = get_local_ip()
    if local_ip == "127.0.0.1":
        err("Sin conexión de red activa."); pause(); return

    default_range = ip_to_cidr(local_ip)
    gateway       = get_gateway()
    print(f"  IP local:  {c('green', local_ip)}")
    print(f"  Gateway:   {c('green', gateway)}")
    print(f"  Rango /24: {c('green', default_range)}\n")

    custom = input(c("yellow", f"  Rango CIDR [{default_range}] → ")).strip()
    target = custom if custom else default_range
    if not validate_cidr(target):
        err(f"Rango CIDR inválido: {target}"); pause(); return

    populate_arp(target)

    arp = get_arp_table()
    ok(f"Tabla ARP: {len(arp)} entradas encontradas")

    xml = run_nmap(target, ["-sn", "--host-timeout", "5s"], timeout=120)
    nmap_hosts = parse_nmap_xml(xml) if xml else []

    nmap_ips = {h["ip"] for h in nmap_hosts}
    all_ips  = nmap_ips | set(arp.keys())
    unified: list[dict] = []
    for h in nmap_hosts:
        unified.append(h)
    for ip in arp:
        if ip not in nmap_ips:
            unified.append({"ip":ip,"mac":"N/A","vendor":"N/A",
                            "hostname":"Desconocido","os":[],"ports":[]})

    unified.sort(key=lambda h: [int(x) for x in h["ip"].split(".")] if h["ip"] != "?" else [0])

    print(f"\n{'═'*62}")
    print(f"  DISPOSITIVOS DETECTADOS — {len(unified)} hosts")
    print(f"{'═'*62}\n")

    t_spin = run_spinner("Resolviendo hostnames")
    with ThreadPoolExecutor(max_workers=30) as ex:
        fut = {ex.submit(resolve_hostname, h["ip"]): h for h in unified}
        for f in as_completed(fut):
            fut[f]["hostname"] = f.result()
    stop_spinner(t_spin)

    print_hosts(unified, arp_table=arp)

    global _last_scan
    _last_scan = {
        "timestamp": datetime.now().isoformat(),
        "target": target, "type": "local_network",
        "hosts": unified
    }
    print(c("dim", f"\n  Total: {len(unified)} dispositivos  |  "
            f"Con MAC: {sum(1 for h in unified if arp.get(h['ip']) or h['mac']!='N/A')}"))
    pause()


def op4_scan_device():
    section("Escaneo profundo de dispositivo")
    target = input(c("yellow", "  IP objetivo → ")).strip()
    if not validate_ip(target):
        err(f"IP inválida: {target}"); pause(); return

    arp = get_arp_table()
    mac = arp.get(target, "N/A")
    if mac == "N/A":
        subprocess.call(["ping","-n","2","-w","500",target],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        creationflags=NO_WIN)
        time.sleep(0.3)
        arp = get_arp_table()
        mac = arp.get(target, "N/A")

    if mac != "N/A":
        ok(f"MAC detectada vía ARP: {mac}  [{oui_lookup(mac)}]")
    else:
        warn("MAC no disponible sin privilegios de admin para este host.")

    info("Lanzando nmap -sV (versiones de servicios)...")
    xml = run_nmap(target, ["-sV", "--open", "--host-timeout", "30s"], timeout=90)
    if not xml:
        pause(); return

    hosts = parse_nmap_xml(xml)
    if not hosts:
        warn("nmap no reportó el host como activo. Puede estar filtrando ICMP.")
        hosts = [{"ip":target,"mac":mac,"vendor":oui_lookup(mac),
                  "hostname":resolve_hostname(target),"os":[],"ports":[]}]

    print(f"\n{'═'*62}\n  REPORTE: {target}\n{'═'*62}\n")
    print_hosts(hosts, arp_table=arp)

    global _last_scan
    _last_scan = {"timestamp":datetime.now().isoformat(),"target":target,
                  "type":"single_device","hosts":hosts}
    pause()


def op5_port_scan():
    section("Escaneo de puertos personalizado")
    target = input(c("yellow","  IP o rango → ")).strip()
    if not (validate_ip(target) or validate_cidr(target)):
        err("Dirección inválida."); pause(); return

    port_input = input(c("yellow","  Puertos [22,80,443  /  1-1024  /  Enter=top100] → ")).strip()
    if port_input:
        if not re.match(r"^[\d,\-]+$", port_input):
            err("Formato inválido."); pause(); return
        port_flag = ["-p", port_input]
    else:
        port_flag = ["-F"]

    arp = get_arp_table()
    xml = run_nmap(target, ["-sV"] + port_flag + ["--open",
                             "--host-timeout","30s"], timeout=150)
    if not xml:
        pause(); return
    hosts = parse_nmap_xml(xml)
    print(f"\n{'═'*62}\n  PUERTOS ABIERTOS — {target}\n{'═'*62}\n")
    print_hosts(hosts, arp_table=arp)

    global _last_scan
    _last_scan = {"timestamp":datetime.now().isoformat(),"target":target,
                  "type":"port_scan","hosts":hosts}
    pause()


def op6_wifi_info():
    section("Información del adaptador Wi-Fi local")
    try:
        raw = subprocess.check_output(
            ["netsh","wlan","show","interfaces"],
            text=True, encoding="cp850", errors="replace",
            creationflags=NO_WIN
        )
    except Exception as e:
        err(f"netsh error: {e}"); pause(); return

    fields = [
        ("SSID actual",     r"(?<!\w)SSID\s*:\s*(.+)"),
        ("BSSID (AP)",      r"BSSID\s*:\s*(.+)"),
        ("Canal",           r"[Cc]anal\s*:\s*(.+)|[Cc]hannel\s*:\s*(.+)"),
        ("Autenticación",   r"[Aa]utenticaci.n\s*:\s*(.+)|[Aa]uthentication\s*:\s*(.+)"),
        ("Cifrado",         r"[Cc]ifrado\s*:\s*(.+)|[Cc]ipher\s*:\s*(.+)"),
        ("Tipo de radio",   r"[Tt]ipo de radio\s*:\s*(.+)|[Rr]adio type\s*:\s*(.+)"),
        ("Señal",           r"[Ss]e.al\s*:\s*(.+)|[Ss]ignal\s*:\s*(.+)"),
        ("Vel. recepción",  r"[Vv]elocidad de recepci.n\s*:\s*(.+)|[Rr]eceive rate.*:\s*(.+)"),
        ("Vel. transmisión",r"[Vv]elocidad de transmisi.n\s*:\s*(.+)|[Tt]ransmit rate.*:\s*(.+)"),
        ("Dirección MAC",   r"Direcci.n f.sica\s*:\s*(.+)|Physical address\s*:\s*(.+)"),
    ]

    print()
    for label, pattern in fields:
        m = re.search(pattern, raw)
        if m:
            val = next((g.strip() for g in m.groups() if g), "N/A")
            if label == "Señal":
                pct = re.search(r"(\d+)", val)
                if pct:
                    n = int(pct.group(1))
                    col = "green" if n >= 70 else ("yellow" if n >= 40 else "red")
                    val = c(col, val)
        else:
            val = c("dim","N/A")
        print(f"  {c('cyan', label+':'): <30} {val}")

    gw = get_gateway()
    print(f"  {c('cyan','Gateway:'): <30} {gw}")
    print(f"  {c('cyan','IP local:'): <30} {get_local_ip()}")
    pause()


def op7_export_json():
    section("Exportar último escaneo a JSON")
    if not _last_scan:
        warn("Sin escaneo en memoria. Ejecuta una opción primero."); pause(); return
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"liarnet_scan_{ts}.json"
    try:
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(_last_scan, f, indent=2, ensure_ascii=False)
        ok(f"Guardado → {c('bold', filename)}")
        print(f"  Hosts:    {len(_last_scan.get('hosts',[]))}")
        print(f"  Ruta:     {os.path.abspath(filename)}")
    except Exception as e:
        err(f"Error guardando: {e}")
    pause()


OPCIONES = {
    "1": op1_scan_available_wifi,
    "2": op2_inspect_wifi,
    "3": op3_scan_local_network,
    "4": op4_scan_device,
    "5": op5_port_scan,
    "6": op6_wifi_info,
    "7": op7_export_json,
}

def main():
    if sys.version_info < (3, 9):
        print("[-] Requiere Python 3.9+"); sys.exit(1)

    if IS_WINDOWS:
        os.system("chcp 65001 > nul 2>&1")
        os.system("")  

    while True:
        show_menu()
        try:
            opcion = input(c("red","LiarNet › ")).strip()
        except (KeyboardInterrupt, EOFError):
            opcion = "8"

        if opcion == "8":
            print(f"\n{c('dim','[*] Cerrando LiarNet...')}\n")
            sys.exit(0)

        handler = OPCIONES.get(opcion)
        if handler:
            handler()
        else:
            warn("Opción no válida.")
            time.sleep(0.7)

if __name__ == "__main__":
    main()