import os
import sys
import time
import threading

BANNER = [
    " ██╗     ██║ █████╗ ██████╗ ███╗   ██╗███████╗████████╗",
    " ██║     ██║██╔══██╗██╔══██╗████╗  ██║██╔════╝╚══██╔══╝",
    " ██║     ██║███████║██████╔╝██╔██╗ ██║█████╗     ██║   ",
    " ██║     ██║██╔══██║██╔══██╗██║╚██╗██║██╔══╝     ██║   ",
    " ███████╗██║██║  ██║██║  ██║██║ ╚████║███████╗   ██║   ",
    " ╚══════╝╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   "
]

animacion_activa = True

def calcular_gradiente_bear(num_linea, total_lineas):
    factor = num_linea / (total_lineas - 1) if total_lineas > 1 else 0
    
    r = 255
    g = int(0 + (255 * factor))
    b = int(0 + (255 * factor))
    
    return f"\033[38;2;{r};{g};{b}m"

def renderizar_linea(linea, num_linea, total_lineas, pos_luz, ancho_cons):
    espacios_centrado = (ancho_cons - len(linea)) // 2
    resultado = " " * espacios_centrado
    
    color_base = calcular_gradiente_bear(num_linea, total_lineas)
    
    for i, char in enumerate(linea):
        if pos_luz - 1 <= i <= pos_luz + 1:
            resultado += f"\033[1;37m{char}" 
        else:
            resultado += f"{color_base}{char}"
                
    return resultado + "\033[0m"

def bucle_animacion():
    global animacion_activa
    
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()
    
    os.system('cls' if os.name == 'nt' else 'clear')
    ancho_maximo = max(len(l) for l in BANNER)
    total_lineas = len(BANNER)
    pos_luz = -5
    
    while animacion_activa:
        try:
            columnas, _ = os.get_terminal_size()
        except OSError:
            columnas = 80

        sys.stdout.write("\033[H")
        sys.stdout.write("\n" * 4) 
        
        for idx, linea in enumerate(BANNER):
            sys.stdout.write(renderizar_linea(linea, idx, total_lineas, pos_luz, columnas) + "\n")
            
        texto_inferior = "(- Enter to pass -)"
        espacios_texto = (columnas - len(texto_inferior)) // 2
        sys.stdout.write("\n" * 2 + " " * espacios_texto + f"\033[37m{texto_inferior}\033[0m\n")
        
        sys.stdout.flush()
        
        pos_luz += 1
        if pos_luz > ancho_maximo + 5:
            pos_luz = -5
            
        time.sleep(0.025)

def ejecutar_ln():
    sys.stdout.write("\033[?25h")
    sys.stdout.flush()
    
    print("\n\033[1;31m[*] Starting LiarNet...\033[0m")
    time.sleep(0.6)
    os.system('cls' if os.name == 'nt' else 'clear')
    
    try:
        if os.name == 'nt':
            os.system('python Ln.py')
        else:
            os.system('python3 Ln.py')
    except Exception as e:
        print(f"[-] Ln.py: {e}")

if __name__ == "__main__":
    hilo_banner = threading.Thread(target=bucle_animacion)
    hilo_banner.daemon = True
    hilo_banner.start()
    
    try:
        input()
    except (KeyboardInterrupt, SystemExit):
        pass
    
    animacion_activa = False
    hilo_banner.join(timeout=0.1)
    ejecutar_ln()